####################################################################################################
### Prepare results data - correct labels and ordering
### Charlie Marsh
### charlie.marsh@mailbox.org; https://github.com/charliem2003
####################################################################################################

library(dplyr)
setwd("/mnt/Work/Oxford/BALI/Bali_Synth_Dbox/Analyses")

################################################################################
### Read in results and store in dataframe 'eff' and merge with dataset info csv
eff <- do.call(rbind,
               lapply(list.files("All_results/Results", full.names = TRUE), read.csv))

info <- read.csv("All_results/Dataset_info.csv")
eff <- left_join(eff[, c("habitat", "pred", "ci_lower", "ci_upper", "rsq_marg", "signif",
                         "ssOP", "ssOGF", "ssTot", "transformation", "dataset")],
                 info, by = "dataset")

############################################
### order categories and habitats as factors
eff$Category <- factor(eff$Category,
                       levels = c("Structure & Environment",
                                  "Photosynthesis traits", "Nutrient traits", "Structural traits",
                                  "Biodiversity", "Functioning"))
eff$Subcategory <- factor(eff$Subcategory,
                       levels = c("Structure", "Microclimate", "Soil properties",
                                  "Photosynthesis traits", "Nutrient traits", "Structural traits",
                                  "Biodiversity (1)", "Biodiversity (2)", "Functioning"))
eff$habitat <- factor(eff$habitat,
                      levels = c("OGF", "MLF", "HLF", "OP"))

################################
### Extra variables for plotting
hOGF.eff <- eff[eff$habitat == "OGF", ] # hline based on OGF valuue
eff$lty <- (eff$signif > 0.05) + 1      # line types based on significance

### For extending y axis 10% beyond CI
eff <- eff %>% 
  group_by(label) %>%
  mutate(y_min = min(ci_lower) - ((max(ci_upper) - min(ci_lower)) * 0.1)) %>%
  mutate(y_max = max(ci_upper) + ((max(ci_upper) - min(ci_lower)) * 0.1)) %>%
  data.frame()



