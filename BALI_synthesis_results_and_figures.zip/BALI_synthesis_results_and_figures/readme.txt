R scripts to regenerate the figures from Marsh et al. 2024 'Logging alters tropical forest structure, while conversion to agriculture reduces biodiversity and functioning'

Run the scripts in order to regenerate the results and figures. You will need to specify the base folder (the folder containing this file), but everything should then run fine provided you have the relevant packages installed.

01_Prepare_data.R
02_Fig2.R
03_Fig3.R
04_SI_figs_S3-5.R

UPDATE V2: Changed to using the marginaleffects package for calculating the confidence intervals around the mean effects sizes in Fig. 2
