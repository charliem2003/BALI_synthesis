####################################################################################################
### 01. Prepare results data
###
### Reads in all results from individual results files, and prepares them for generating figures by
### adding correct labels and ordering
###
### Charlie Marsh
### charlie.marsh@mailbox.org; https://github.com/charliem2003
####################################################################################################

####################################################################################################
### Set-up

rm(list = ls())

### load in libraries
library(dplyr)

### Path to directory to which the project is placed - ***You need to change this***
baseDir <- "BALI_synthesis_results_and_figures"

### Directory with individual spreadsheets with model results
resDir <- file.path(baseDir, "Results")

####################################################################################################
### Read in results and store in dataframe 'eff' and merge with dataset info csv

### Spreadsheet that has info for plot arrangements
info <- read.csv(file.path(baseDir, "Dataset_info.csv"))

### read in all results and join with info
eff <- do.call(rbind, lapply(list.files(resDir, full.names = TRUE), read.csv)) %>%
  as_tibble()
eff <- eff %>%
  select(habitat, pred, ci_lower, ci_upper, rsq_marg, signif, ssOP, ssOGF, ssTot, dataset) %>%
  left_join(info, by = "dataset")

####################################################################################################
### Correct ordering of categories and habitats factors

eff <- eff %>%
  mutate(Category = factor(Category,
                           levels = c("Structure & Environment",
                                      "Photosynthesis traits",
                                      "Nutrient traits",
                                      "Structural traits",
                                      "Biodiversity",
                                      "Functioning"))) %>%
  mutate(Subcategory = factor(Subcategory,
                              levels = c("Structure",
                                         "Microclimate",
                                         "Soil properties",
                                         "Photosynthesis traits",
                                         "Nutrient traits",
                                         "Structural traits",
                                         "Biodiversity (1)",
                                         "Biodiversity (2)",
                                         "Functioning"))) %>%
  mutate(habitat = factor(habitat,
                          levels = c("OGF", "MLF", "HLF", "OP")))

####################################################################################################
### Extra variables and adjustments for plotting

### Dataframe for drawing horizontal line for OGF effects size for easier visual comparisons
hOGF.eff <- eff %>% 
  filter(habitat == "OGF")

### Line type to use (solid = significant, dashed = non-significant)
eff <- eff %>% 
  mutate(lty = (eff$signif > 0.05) + 1)

### Variable for extending y axis 10% beyond CI for nicer plotting
eff <- eff %>% 
  group_by(label) %>%
  mutate(y_min = min(ci_lower) - ((max(ci_upper) - min(ci_lower)) * 0.1)) %>%
  mutate(y_max = max(ci_upper) + ((max(ci_upper) - min(ci_lower)) * 0.1))


