####################################################################################################
### Functions for generating plots of effects sizes against disturbance for a given category or
### subcategory
###
### There are different options depending on the exact layout and look of the plot, mainly related
### to whether you want an extended version (every variable is on it's own row; the versions in the
### the Supplementary Material), or a compact version where related variables are grouped (the 
### version in the main text).
###
### Charlie Marsh
### charlie.marsh@mailbox.org; https://github.com/charliem2003
####################################################################################################

####################################################################################################
### Function for generating nicer facet labels

label_wrap <- function(labels, width = 15, multi_line = TRUE){
  labels <- label_value(labels, multi_line = multi_line)
  label <- lapply(labels, function(x) {
    x <- strwrap(x, width = width, simplify = FALSE)
    vapply(x, paste, character(1), collapse = "\n")
  })
  return(as.factor(label[[1]]))
}

####################################################################################################
### The main plotting function for plotting an individual category

plot.cat <- function(category       = NULL,         # the individual category to be plotted (in which case subcategory should be NULL)
                     subcategory    = NULL,         # the subcategory to be plotted (in which case category should be NULL)
                     compact        = FALSE,        # plot the compact version; TRUE or FALSE
                     label.category = TRUE,         # facet label for category
                     label.level    = TRUE,         # facet label for ecological level
                     label.cex      = 7.5,          # sizes of variable labels
                     label.x        = TRUE,         # include x-axis label
                     label.y        = TRUE,         # include y-axis label
                     hline          = TRUE,         # include horizontal line for OGF mean effect size
                     cat.colour     = "white",      # Colour to use for category labels
                     facet.colour   = "lightcyan2", # Colour to use in facet label box
                     save.image     = TRUE,         # Write image to file (both .pdf and .png)
                     print          = FALSE,        # Plot in plot window
                     return.plot    = FALSE,        # Return grob object for later plotting
                     path           = NULL)         # Folder path for saving image
{
  
  ##############################################################################
  ### Prepare data
  if(!is.null(category)) {
    dd.cat <- droplevels(dplyr::filter(eff, Category == category))
    dd.cat$label <- factor(dd.cat$label, 
                           levels = unique(dd.cat$label[order(dd.cat$Order_level)]))
    cat.name <- gsub("_", " ", as.character(category))
  }
  if(!is.null(subcategory)) {
    dd.cat <- droplevels(dplyr::filter(eff, Subcategory == subcategory))
    dd.cat$label <- factor(dd.cat$label, 
                           levels = unique(dd.cat$label[order(dd.cat$Order_sublevel)]))
    cat.name <- gsub("_", " ", as.character(subcategory))
  }
  
  if(compact == TRUE) {
    compacted <- as.character(dd.cat$label[dd.cat$habitat == "OGF"][!is.na(dd.cat$Compact[dd.cat$habitat == "OGF"])])
    
    dd.cat$label <- as.character(dd.cat$label)
    dd.cat$label_sub <- dd.cat$label
    for(lab in compacted) {
      colon <- regexpr(':', lab)[1]
      dd.cat$label_sub[dd.cat$label_sub == lab] <- substr(lab, colon + 2, nchar(lab))
      dd.cat$label[dd.cat$label == lab] <- substr(lab, 1, colon - 1)
    }
    dd.cat$label <- factor(dd.cat$label,
                           levels = unique(dd.cat$label[order(dd.cat$Order_compact)]))
    dd.cat$label_sub <- factor(dd.cat$label_sub,
                               levels = unique(dd.cat$label_sub[order(dd.cat$Order_compact)]))
  }
  datasets <- levels(dd.cat$label)
  ndatasets <- nlevels(dd.cat$label)
  
  ### background colours - 1st panel for traits needs to be red
  cat.col <- data.frame(label = datasets,
                        col.panel = rep(c("white", facet.colour),
                                        ceiling(ndatasets / 2))[1:ndatasets],
                        col.facet = rep(c("grey80", "grey70"),
                                        ceiling(ndatasets / 2))[1:ndatasets])
  if((length(grep("traits", category)) == 1) | (length(grep("traits", subcategory)))) {
    levels(cat.col$col.panel) <- c(levels(cat.col$col.panel), "pink")
    cat.col$col.panel[1] <- "pink"
    levels(cat.col$col.facet) <- c(levels(cat.col$col.facet), "mistyrose2")
    cat.col$col.facet[1] <- "mistyrose2"
  }
  dd.cat <- dplyr::left_join(dd.cat, cat.col, by = "label")
  
  ##############################################################################
  ### Overall layout of plot
  
  if((label.level == TRUE)  & (label.x == TRUE))  {
    plot.height <- c(0.75, rep(1.75, ndatasets), 0.75, 1)
  }
  if((label.level == TRUE ) & (label.x == FALSE)) {
    plot.height <- c(0.75, rep(1.75, ndatasets), 0.2, 0.01)
  }
  if((label.level == FALSE) & (label.x == TRUE))  {
    plot.height <- c(0.02, rep(1.75, ndatasets), 0.75, 1)
  }
  if((label.level == FALSE) & (label.x == FALSE)) {
    plot.height <- c(0.02, rep(1.75, ndatasets), 0.1, 0.01)
  }
  
  gt <- gtable(widths = grid::unit(c(0.7, 1.2, 7.2, 0.9),
                                   c("cm", "cm", "cm", "cm")),
               heights = grid::unit(plot.height,
                                    c("cm", rep("cm", ndatasets), "cm", "cm")))
  
  ##############################################################################
  ### Loop through plotting each dataset
  
  for(i in 1:ndatasets) {
    dd.pl <- dplyr::filter(dd.cat, label == datasets[i])
    if((compact == TRUE) & (length(unique(dd.pl$label_sub)) > 1)) {
      dd.pl$label_sub <- factor(dd.pl$label_sub,
                                levels = unique(dd.pl$label_sub[order(dd.pl$Compact)]))
    }
    
    ### main plot
    if(compact == FALSE) { p <- ggplot(data = dd.pl, aes(habitat, pred)) + theme() }
    if(compact == TRUE)  {
      p <- ggplot(data = dd.pl, aes(habitat, pred, colour = label_sub)) +
        scale_colour_manual(values = c("black",
                                       rgb(213,  97,   0, maxColorValue = 255),
                                       rgb(86,  180, 233, maxColorValue = 255),
                                       rgb(0,   158, 115, maxColorValue = 255),
                                       rgb(255, 159,   0, maxColorValue = 255))) +
        theme(axis.ticks.y = element_blank(),
              axis.text.y = element_blank())
    }
    
    p <- p +
      theme_update(panel.background = element_rect(fill = "white"),
                   panel.grid.major = element_blank(),
                   panel.grid.minor = element_blank(),
                   axis.ticks.x = element_blank(),
                   axis.text.x = element_blank(),
                   plot.margin = unit(c(0.1, 0.1, 0.1, 0.1), "cm"),
                   panel.spacing.y = unit(0, "lines")) +
      labs(y = NULL, x = NULL) +
      geom_blank(data = dd.pl, aes(x = habitat, y = y_min)) +
      geom_blank(data = dd.pl, aes(x = habitat, y = y_max)) +
      geom_rect(xmin = -Inf, xmax = Inf, ymin = -Inf, ymax = Inf,
                fill = dd.pl$col.panel, colour = NA) +
      scale_y_continuous(position = "right") 
    if(hline == TRUE) {
      p <- p +
        geom_abline(intercept = dd.pl$pred[dd.pl$habitat == "OGF"], slope = 0,
                    lwd = 1.2, col = "grey80")
    }
    p <- p +
      geom_errorbar(data = dd.pl, width = 0.2, colour = "grey70",
                    aes(x = habitat, ymin = ci_lower, ymax = ci_upper)) +
      geom_point(data = dd.pl, aes(habitat, pred), size = 1.5) +
      geom_path(data = dd.pl, aes(as.numeric(habitat), pred),
                lty = dd.pl$lty, lwd = 0.7, show.legend = FALSE) +
      xlim(c("OGF", "MLF", "HLF", "OP"))
    
    ### add legend if necessary
    if(compact == TRUE) {
      if(length(unique(dd.pl$habitat)) == 3) {
        p <- p + theme_update(legend.position = c(0.6, 0.6),
                              legend.background = element_blank(),
                              legend.key = element_blank(),
                              legend.direction = "vertical",
                              legend.key.height = unit(0.5, "line"),
                              legend.title = element_blank())
      }
      if(length(unique(dd.pl$habitat)) == 4) {
        p <- p + theme_update(legend.position = c(0, 0.9),
                              legend.justification = "left",
                              legend.background = element_blank(),
                              legend.spacing.x = unit(0.1, "cm"),
                              legend.key = element_blank(),
                              legend.direction = "horizontal",
                              legend.title = element_blank())
      }
    }
    if(compact == FALSE) { p <- p + theme_update(legend.position = "none") }
    
    ### convert to grob object
    p <- ggplotGrob(p)
    
    ### add plot
    gt <- gtable_add_grob(gt, p$grobs[[6]], 
                          t = i + 1, b = i + 1, l = 3, r = 3,
                          name = paste(i, 1, sep = "."))
    
    ### add legend
    if(length(unique(dd.pl$label_sub)) > 1) {
      gt <- gtable_add_grob(gt, p$grobs[[15]], 
                            t = i + 1, b = i + 1, l = 3, r = 3,
                            name = paste(i, "legend", sep = "."))
    }
    
    ### add y-axis
    if(label.y == TRUE) {
      gt <- gtable_add_grob(gt, p$grobs[[9]], 
                            t = i + 1, b = i + 1, l = 4, r = 4,
                            name = paste(i, 2, sep = "."))
    }
    
    ### facet labels
    gt <- gtable_add_grob(gt, 
                          list(rectGrob(gp = gpar(col = NA,
                                                  fill = as.character(dd.pl$col.facet))),
                               textGrob(label_wrap(unique(dd.pl$label)), rot = 90,  
                                        gp = gpar(fontsize = label.cex, fontfamily = "Arial",
                                                  fontface = "plain", col = "black"))), 
                          t = i + 1, b = i + 1, l = 2, r = 2,
                          name = paste(c("a", "b"), 1, sep = "."))
  }
  
  ##############################################################################
  ### Category label
  
  ### if we don't want the category labels draw as coloured box
  if(label.category == FALSE) {
    gt <- gtable_add_grob(gt,
                          list(rectGrob(gp = gpar(lwd = 2, fill = cat.colour)),
                               textGrob(cat.name, rot = 90,
                                        gp = gpar(fontsize = 10, fontfamily = "Arial",
                                                  fontface = "plain", col = "black"))),
                          t = 2, b = ndatasets + 1, l = 1, r = 1,
                          name = c("Cat.box", "Cat.txt"))
  }
  
  ### if we also want the category labels draw as individual lines
  if(label.category == TRUE) {
    gt <- gtable_add_grob(gt, 
                          list(rectGrob(gp = gpar(lwd = 2, fill = "grey40")),
                               textGrob(cat.name, rot = 90,
                                        gp = gpar(fontsize = 12, fontfamily = "Arial",
                                                  fontface = "plain", col = "white"))), 
                          t = 2, b = ndatasets + 1, l = 1, r = 1,
                          name = c("Cat.box", "Cat.txt"))
    
    gt <- gtable_add_grob(gt,
                          linesGrob(x = c(0, 0), y = c(0, 1), gp = gpar(lwd = 2)), 
                          t = 1, b = ndatasets + 1, l = 2, r = 2,
                          name = "Cat.box.r")
  }
  
  ##############################################################################
  ### Level labels (if no labels simply draw line at top)
  
  if(label.level == FALSE) {
    ### Mean effect line
    gt <- gtable_add_grob(gt,
                          linesGrob(x = c(0, 1), y = c(1, 1), gp = gpar(lwd = 2)), 
                          t = 2, b = 2, l = 2, r = 3,
                          name = "Eff.box.b")
  }
  
  if(label.level == TRUE) {
    if(cat.name %in% c("Structure", "Microclimate", "Soil properties", "Structure & Environment")) { lev <- "LEVEL 1" }
    if(cat.name %in% c("Photosynthesis traits", "Structural traits", "Nutrient traits")) { lev <- "LEVEL 2" }
    if(cat.name %in% c("Biodiversity", "Biodiversity (1)", "Biodiversity (2)")) { lev <- "LEVEL 3" }
    if(cat.name == "Functioning") { lev <- "LEVEL 4" }
    
    ### Mean effect label
    gt <- gtable_add_grob(gt, 
                          list(rectGrob(gp = gpar(lwd = 2, fill = "grey70")),
                               textGrob(lev,  
                                        gp = gpar(fontsize = 12, fontfamily = "Arial",
                                                  fontface = "plain", col = "black"))),
                          t = 1, b = 1, l = 1, r = 3,
                          # t = 1, b = 1, l = 2, r = 3,
                          name = c("Eff.box", "Eff.txt"))
  }
  
  ##############################################################################
  ### x-axes labels and title
  
  ### Axis ticks
  p <- ggplotGrob(ggplot(data = dd.pl, aes(habitat, pred)) +
                    theme(panel.spacing.y = unit(0, "lines"),
                          axis.text.x = element_text(colour = "black"),
                          axis.ticks.x = element_line(colour = "black"),
                          legend.position = "none") +
                    xlim(c("OGF", "MLF", "HLF", "OP")))
  gt <- gtable_add_grob(gt, 
                        p$grobs[[7]], 
                        t = ndatasets + 2, b = ndatasets + 2, l = 3, r = 3,
                        name = "Hab.eff.ticks")
  
  if(label.x == TRUE) {
    ### Habitat labels
    gt <- gtable_add_grob(gt,
                          p$grobs[[7]], 
                          t = ndatasets + 2, b = ndatasets + 2, l = 3, r = 3,
                          name = "Hab.eff")
    
    ### x-axis title
    gt <- gtable_add_grob(gt,
                          textGrob("Disturbance",
                                   gp = gpar(fontsize = 10, fontfamily = "Arial",
                                             fontface = "plain", col = "black")),
                          t = ndatasets + 3, b = ndatasets + 3, l = 3, r = 3,
                          name = "Dis.txt")
  }
  
  ##############################################################################
  ### bottom borders
  
  gt <- gtable_add_grob(gt,
                        linesGrob(x = c(0, 4), y = c(0, 0),
                                  gp = gpar(col = "black", lwd = 2)),
                        t = ndatasets + 1, b = ndatasets + 1,
                        l = 2, r = 3,
                        name = "Eff.line")
  
  ##############################################################################
  ### right borders
  
  gt <- gtable_add_grob(gt,
                        linesGrob(x = c(0, 0), y = c(0, 1),
                                  gp = gpar(col = "black", lwd = 2)),
                        t = 2, b = ndatasets + 1,
                        l = 4, r = 4,
                        name = "y.axis.line")
  
  ##############################################################################
  ### Save image
  
  if(save.image == TRUE) {
    ### Save png
    png(file.path(path, paste0(category, ".png")),
        width = 18, height = sum(plot.height), units = "cm", res = 600)
    grid.newpage()
    grid.draw(gt)
    dev.off()
    
    ### Save pdf
    cairo_pdf(file.path(path, paste0(category, ".pdf")),
              width = 18 * 0.394,
              height = sum(plot.height) * 0.394)
    grid.newpage()
    grid.draw(gt)
    dev.off()
  }
  
  ##############################################################################
  ### Print
  if(print == TRUE) {
    grid.newpage()
    grid.draw(gt)
  }
  
  ##############################################################################
  ### Save final plot
  if(return.plot == TRUE) {
    return(gt)
  }
}
