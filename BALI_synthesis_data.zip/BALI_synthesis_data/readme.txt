Prepared and standardised data for the manuscript 'Marsh et al. High level ecosystem functions more resilient to tropical forest degradation and deforestation' in prep.

Data has been already been cleaned, z-score standardised and formatted to carry out the analyses described in the respective RMarkdown documents (available in BALI_synthesis_analyses.zip). Each file is a .rds data file that can be loaded into R through:

dd <- readRDS("path/to/rds/file/name_of_file.rds") 
         
To repeat any given analysis, follow the respective rmarkdown document, excluding the data manipulation steps:

1. Read in the data file as described above:
	dd <- readRDS(paste0("path/to/rds/file/", "name_of_file.rds")) 
2. Run the code at the top of the markdown workflow (sections "Data information" and "Load in necessary libraries")
3. Do not run the sections "Read in data" through to "Visual inspection of the data"
4. Continue the analysis from the 'Modelling' section
