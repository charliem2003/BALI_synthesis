################################################################################
### Plots dd results in compact version - ie groups related datasets into one facet - for fig. 2 in
### the main text. Generates separate plots that are then processed and joined in inkscape
### Charlie Marsh
### charlie.marsh@mailbox.org; https://github.com/charliem2003
################################################################################

library(tidyr)
library(dplyr)
library(ggplot2)
library(cowplot)
setwd("/mnt/Work/Oxford/BALI/Bali_Synth_Dbox/Analyses")

####################################################################################################
### Read in data

source("All_results/01_Prepare_data.R")
source("All_results/Plotting_functions.R")

####################################################################################################
### Join individual traits into single category 'Tree traits'

dd <- eff

### we only need the one entry for each dataset (other habitats duplicate SS values)
dd <- dd[!duplicated(dd$ssOGF), ]

### Only keep aggregated tree traits
traits <- c(dd$label[(dd$Category == "Photosynthesis traits") & (dd$label != "Photosyn. traits")],
            dd$label[(dd$Category == "Nutrient traits") & (dd$label != "Nutrient traits")],
            dd$label[(dd$Category == "Structural traits") & (dd$label != "Structural traits")])
dd <- dd[!(dd$label %in% traits), ]

### Remove litter decomposition (only OGF and HLF investigated)
dd <- dd[dd$label != "Litter decomp.", ]

### Ordering of categories
dd$Category <- factor(dd$Category,
                      levels = c(levels(dd$Category), "Tree traits"))
dd$Category[dd$Category %in% c("Photosynthesis traits", "Structural traits", "Nutrient traits")] <- "Tree traits"
dd$Category <- droplevels(dd$Category)
dd$Category <- factor(dd$Category,
                      levels = c("Functioning", "Biodiversity", "Tree traits", "Structure & Environment"))

####################################################################################################
### datasets with oil palm sampled
####################################################################################################

### Remove datasets that haven't sampled oil palm
ddOP <- dd[!is.na(dd$ssOP), ]

### calculate explained variance as proportion of sum SS
ddOP <- ddOP %>%
  group_by(dataset) %>%
  summarise(ssOGF_prop = ssOGF / ssTot,
            ssOP_prop  = ssOP  / ssTot,
            ssRem_prop = (ssTot - ssOGF - ssOP) / ssTot) %>%
  pivot_longer(cols = c("ssOP_prop", "ssOGF_prop", "ssRem_prop"), names_to = "Component") %>%
  left_join(ddOP) %>%
  select(dataset, Component, value, rsq_marg, label, Category)

### order component levels for plotting
ddOP$Component <- factor(ddOP$Component,
                         levels = c("ssOP_prop", "ssRem_prop", "ssOGF_prop"))

### order datasets by proportion of ss explained by OGF-Forest component
ddOP$label <- factor(ddOP$label, 
                     levels = unique(ddOP$label)[rev(order(ddOP$value[ddOP$Component == "ssOGF_prop"]))])

### vector for labelling datasets names by category
Category <- as.character(ddOP$Category[ddOP$Component == "ssOP_prop"])
Category <- Category[rev(order(ddOP$value[ddOP$Component == "ssOGF_prop"]))]
Category[Category == "Structure & Environment"] <- "blue"
Category[Category == "Tree traits"] <- "grey"
Category[Category == "Biodiversity"] <- "dark red"
Category[Category == "Functioning"] <- "dark green"

### the main plot
plOP <- ggplot(ddOP, aes(label, value, fill = Component)) +
  theme(panel.background = element_rect(fill = "white", colour = "black"),
        strip.background = element_rect(colour = "black"),
        # legend.position = "none",
        axis.text.y = element_text(colour = Category),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank()) +
  scale_fill_manual(values = c("ssOGF_prop" = "Forestgreen",
                               "ssRem_prop" = "orange",
                               "ssOP_prop"  = "Skyblue")) +
  scale_y_continuous(expand = c(0.001, 0.001)) +
  scale_alpha(range = c(0.2, 1)) +
  geom_bar(aes(alpha = rsq_marg), position = "fill", stat = "identity") +
  coord_flip() +
  labs(y = "Proportion of explained variances",
       x = NULL)

### dataframe for drawing the legend
leg <- expand.grid(data.frame(x = c("OGF", "MLF", "HLF"), y = c("OP", "HLF", "MLF")))
leg$col <- c("Skyblue", "Skyblue", "Skyblue",
             "Forestgreen", "Orange", NA,
             "Forestgreen", NA, NA)
leg$text <- c("OGF-OP", "MLF-OP", "HLF-OP",
              "OGF-HLF", "MLF-HLF", NA,
              "OGF-MLF",NA, NA)
leg$border  <- c("black", "black", "black",
                 "black", "black", NA,
                 "black",NA, NA)

### draw the legend
plOP_legend <- ggplot() +
  theme(panel.background = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank()) +
  labs(x = NULL, y = NULL) +
  geom_tile(data = leg, aes(x, y, fill = col), col = leg$border) +
  scale_fill_identity() +
  geom_text(data = leg, aes(x, y, label = text)) +
  coord_fixed()

### legend for text colour
leg <- data.frame(label = c("Structure & Environment", "Tree traits", "Biodiversity", "Functioning"),
                  col = c("blue", "grey", "dark red", "dark green"),
                  x = rep(1, 4), y = 4:1)
cat_legend <- ggplot(leg, aes(x, y)) +
  theme_map() +
  lims(x = c(0, 5)) +
  coord_fixed() +
  geom_tile(fill = leg$col) +
  geom_text(aes(1.6, y), label = leg$label, col = leg$col, hjust = "left")

### combine all together
png("/mnt/Work/Oxford/BALI/Bali_Synth_Dbox/Analyses/Figures/Raw/Contrasts_OP.png",
    width = 11, height = 8, units = "in", bg = "white", res = 600)
ggdraw() +
  draw_plot(plOP, 0, 0, 0.75, 1) +
  draw_plot(plOP_legend, 0.72, 0.7, 0.3, 0.3) +
  draw_plot(cat_legend, 0.72, 0, 0.25, 0.9)
dev.off()


####################################################################################################
### datasets without oil palm sampled#
####################################################################################################

ddNoOP <- dd[!duplicated(dd$ssOGF), ]

### Only datasets that haven't sampled oil palm
ddNoOP <- ddNoOP[is.na(ddNoOP$ssOP), ]

### calculate explained variance as proportion of sum SS
ddNoOP <- ddNoOP %>%
  group_by(dataset) %>%
  summarise(ssOGF_prop = ssOGF / ssTot,
            ssRem_prop = (ssTot - ssOGF) / ssTot) %>%
  pivot_longer(cols = c("ssOGF_prop", "ssRem_prop"), names_to = "Component") %>%
  left_join(ddNoOP) %>%
  select(dataset, Component, value, rsq_marg, label, Category)

### order component levels for plotting
ddNoOP$Component <- factor(ddNoOP$Component,
                           levels = c("ssRem_prop", "ssOGF_prop"))

### order datasets by proportion of ss explained by MLF-HLF component
ddNoOP$label <- factor(ddNoOP$label, 
                       levels = unique(ddNoOP$label)[order(ddNoOP$value[ddNoOP$Component == "ssRem_prop"])])

### vector for labelling datasets names by category
Category <- as.character(ddNoOP$Category[ddNoOP$Component == "ssOGF_prop"])
Category <- Category[order(ddNoOP$value[ddNoOP$Component == "ssRem_prop"])]
Category[Category == "Structure & Environment"] <- "blue"
Category[Category == "Tree traits"] <- "grey"
Category[Category == "Biodiversity"] <- "dark red"
Category[Category == "Functioning"] <- "dark green"

### the main plot
plNoOP <- ggplot(ddNoOP, aes(label, value, fill = Component)) +
  theme(panel.background = element_rect(fill = "white", colour = "black"),
        strip.background = element_rect(colour = "black"),
        # legend.position = "none",
        axis.text.y = element_text(colour = Category),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank()) +
  scale_fill_manual(values = c("ssOGF_prop" = "Forestgreen",
                               "ssRem_prop" = "orange")) +
  scale_y_continuous(expand = c(0.001, 0.001)) +
  scale_alpha(range = c(0.2, 1)) +
  geom_bar(aes(alpha = rsq_marg), position = "fill", stat = "identity") +
  coord_flip() +
  labs(y = "Proportion of explained variances",
       x = NULL)

### dataframe for drawing the legend
leg <- expand.grid(data.frame(x = c("OGF", "MLF"), y = c("HLF", "MLF")))
leg$col <- c("Forestgreen", "Orange",
             "Forestgreen", NA)
leg$text <- c("OGF-HLF", "MLF-HLF",
              "OGF-MLF",NA)
leg$border  <- c("black", "black", 
                 "black", NA)

### draw the legend
plNoOP_legend <- ggplot() +
  theme(panel.background = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank()) +
  labs(x = NULL, y = NULL) +
  geom_tile(data = leg, aes(x, y, fill = col), col = leg$border) +
  scale_fill_identity() +
  geom_text(data = leg, aes(x, y, label = text)) +
  coord_fixed()

### legend for text colour
leg <- data.frame(label = c("Structure & Environment", "Tree traits", "Biodiversity", "Functioning"),
                  col = c("blue", "grey", "dark red", "dark green"),
                  x = rep(1, 4), y = 4:1)
cat_legend <- ggplot(leg, aes(x, y)) +
  theme_map() +
  lims(x = c(0, 5)) +
  coord_fixed() +
  geom_tile(fill = leg$col) +
  geom_text(aes(1.6, y), label = leg$label, col = leg$col, hjust = "left")

### combine all together
png("/mnt/Work/Oxford/BALI/Bali_Synth_Dbox/Analyses/Figures/Raw/Contrasts_No_OP.png",
    width = 11, height = 8, units = "in", bg = "white", res = 600)
ggdraw() +
  draw_plot(plNoOP, 0, 0, 0.75, 1) +
  draw_plot(plNoOP_legend, 0.72, 0.7, 0.3, 0.3) +
  draw_plot(cat_legend, 0.72, 0, 0.25, 0.9)
dev.off()

