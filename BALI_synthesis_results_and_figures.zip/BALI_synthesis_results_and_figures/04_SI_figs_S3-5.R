################################################################################
### Plots all results in long version - ie one dataset per facet (as opposed to main text version
### that groups some related datasets into one facet) - with full labelling for the SI (figs S3-5)
### Charlie Marsh
### charlie.marsh@mailbox.org; https://github.com/charliem2003
################################################################################

library(gridExtra)
library(grid)
library(gtable)
library(ggplot2)
setwd("/mnt/Work/Oxford/BALI/Bali_Synth_Dbox/Analyses")

####################################################################################################
### Read in data
####################################################################################################

source("All_results/01_Prepare_data.R")
source("All_results/Plotting_functions.R")

####################################################################################################
#### Plot 1: Level 1 Structure, Microclimate, Soil properties
####################################################################################################

### Level 1 - Structure, microclimate and soil properties
pl.str <- plot.cat(subcategory = "Structure", label.category = TRUE, label.level = TRUE, label.x = TRUE, compact = FALSE,
                   label.cex = 7.3, cat.colour = "white", save.image = FALSE, print = FALSE, return.plot = TRUE)
pl.micro <- plot.cat(subcategory = "Microclimate", label.category = TRUE, label.level = TRUE, label.x = TRUE, compact = FALSE,
                     label.cex = 7.3, cat.colour = "white", save.image = FALSE, print = FALSE, return.plot = TRUE)
pl.soil <- plot.cat(subcategory = "Soil properties", label.category = TRUE, label.level = TRUE, label.x = TRUE, compact = FALSE,
                    label.cex = 7.3, cat.colour = "white", save.image = FALSE, print = FALSE, return.plot = TRUE)

gt1 <- gtable(widths = unit(c(sum(as.numeric(pl.str$pdf.version$widths)), 0.5,
                              sum(as.numeric(pl.micro$pdf.version$widths)), 0.5,
                              sum(as.numeric(pl.soil$pdf.version$widths))),
                            "cm"),
              heights = unit(c(0.75,
                               rep(c(1, 0.75),
                                   max(as.numeric(
                                     strtrim(pl.soil$pdf.version$layout$name[grep("[0-9]", strtrim(pl.soil$pdf.version$layout$name, 2))], 2)),
                                     na.rm = TRUE) + 1)),
                             "cm"))

### column 1 - Structure
gt1 <- gtable_add_grob(gt1, pl.str$pdf.version,
                       l = 1, r = 1, t = 1,
                       b = 3 + (length(grep("1.75", pl.str$pdf.version$heights)) * 2),
                       name = "pl.str")

### column 2 - Microclimate
gt1 <- gtable_add_grob(gt1, pl.micro$pdf.version,
                       l = 3, r = 3, t = 1,
                       b = 3 + (length(grep("1.75", pl.micro$pdf.version$heights)) * 2),
                       name = "pl.micro")

### column 3 - Soil properties
gt1 <- gtable_add_grob(gt1, pl.soil$pdf.version,
                       l = 5, r = 5, t = 1,
                       b = 3 + (length(grep("1.75", pl.soil$pdf.version$heights)) * 2),
                       name = "pl.soil")

png("/mnt/Work/Oxford/BALI/Bali_Synth_Dbox/Analyses/Figures/SI/Level1.png",
    width = sum(as.numeric(gt1$widths)),
    height = sum(as.numeric(gt1$heights)),
    units = "cm", res = 600)
grid.newpage()
grid.draw(gt1)
dev.off()

################################################################################
#### Plot 2: Level 2 - col1: Str traits, col2: Nutr traits, col3: Photo traits
################################################################################

### Level 2
pl.strait <- plot.cat(subcategory = "Structural traits", label.category = TRUE, label.level = TRUE, label.x = TRUE, compact = FALSE, 
                      label.cex = 7.3, cat.colour = "white", save.image = FALSE, print = FALSE, return.plot = TRUE)
pl.ptrait <- plot.cat(subcategory = "Photosynthesis traits", label.category = TRUE, label.level = TRUE, label.x = TRUE, compact = FALSE,
                      label.cex = 7.3, cat.colour = "white", save.image = FALSE, print = FALSE, return.plot = TRUE)
pl.ntrait <- plot.cat(subcategory = "Nutrient traits", label.category = TRUE, label.level = TRUE, label.x = TRUE, compact = FALSE,
                      label.cex = 7.3, cat.colour = "white", save.image = FALSE, print = FALSE, return.plot = TRUE)

gt2 <- gtable(widths = unit(c(sum(as.numeric(pl.strait$pdf.version$widths)), 0.5,
                              sum(as.numeric(pl.ntrait$pdf.version$widths)), 0.5,
                              sum(as.numeric(pl.ptrait$pdf.version$widths))),
                            "cm"),
              heights = unit(c(0.75,
                               rep(c(1, 0.75),
                                   max(as.numeric(
                                     strtrim(pl.ptrait$pdf.version$layout$name[grep("[0-9]", strtrim(pl.ptrait$pdf.version$layout$name, 2))], 2)),
                                     na.rm = TRUE) + 1)),
                             "cm"))

### column 1 - Photosynthesis traits
gt2 <- gtable_add_grob(gt2, pl.ptrait$pdf.version,
                       l = 1, r = 1,
                       t = 1,
                       b = 3 + (length(grep("1.75", pl.ptrait$pdf.version$heights)) * 2),
                       name = "pl.ptraits")

### column 2 - Nutrient traits
gt2 <- gtable_add_grob(gt2, pl.ntrait$pdf.version,
                       l = 3, r = 3,
                       t = 1,
                       b = 3 + (length(grep("1.75", pl.ntrait$pdf.version$heights)) * 2),
                       name = "pl.ntraits")

### column 3 - Structural traits
gt2 <- gtable_add_grob(gt2, pl.strait$pdf.version,
                       l = 5, r = 5,
                       t = 1,
                       b = 3 + (length(grep("1.75", pl.strait$pdf.version$heights)) * 2),
                       name = "pl.straits")

png("/mnt/Work/Oxford/BALI/Bali_Synth_Dbox/Analyses/Figures/SI/Level2.png",
    width = sum(as.numeric(gt2$widths)),
    height = sum(as.numeric(gt2$heights)),
    units = "cm", res = 600)
grid.newpage()
grid.draw(gt2)
dev.off()

################################################################################
#### Plot 3: Level 3+4 - col1: Diversity 1-10, col2: Diversity 11:22, col3: Functions
################################################################################

pl.div1 <- plot.cat(subcategory = "Biodiversity (1)", label.category = TRUE, label.level = TRUE, label.x = TRUE, compact = FALSE,
                    label.cex = 7.3, cat.colour = "white", save.image = FALSE, print = FALSE, return.plot = TRUE)
pl.div2 <- plot.cat(subcategory = "Biodiversity (2)", label.category = TRUE, label.level = TRUE, label.x = TRUE, compact = FALSE,
                    label.cex = 7.3, cat.colour = "white", save.image = FALSE, print = FALSE, return.plot = TRUE)
pl.fun <- plot.cat(subcategory = "Functioning", label.category = TRUE, label.level = TRUE, label.x = TRUE, compact = FALSE,
                   label.cex = 7.3, cat.colour = "white", save.image = FALSE, print = FALSE, return.plot = TRUE)

gt3.4 <- gtable(widths = unit(c(sum(as.numeric(pl.div1$pdf.version$widths)), 0.5,
                                sum(as.numeric(pl.div1$pdf.version$widths)), 0.5,
                                sum(as.numeric(pl.div1$pdf.version$widths))),
                              "cm"),
                heights = unit(c(0.75,
                                 rep(c(0.75, 1),
                                     max(as.numeric(
                                       strtrim(pl.div1$pdf.version$layout$name[grep("[0-9]", strtrim(pl.div1$pdf.version$layout$name, 2))], 2)),
                                       na.rm = TRUE) + 1)),
                               "cm"))

### column 1 - First half of biodiversity 
gt3.4 <- gtable_add_grob(gt3.4, pl.div1$pdf.version,
                         l = 1, r = 1, t = 1,
                         b = 3 + (length(grep("1.75", pl.div1$pdf.version$heights)) * 2),
                         name = "pl.div1")

### column 2 - Second half of biodiversity 
gt3.4 <- gtable_add_grob(gt3.4, pl.div2$pdf.version,
                         l = 3, r = 3, t = 1,
                         b = 3 + (length(grep("1.75", pl.div2$pdf.version$heights)) * 2),
                         name = "pl.div2")

### column 3 - Functioning 
gt3.4 <- gtable_add_grob(gt3.4, pl.fun$pdf.version,
                         l = 5, r = 5, t = 1,
                         b = 3 + (length(grep("1.75", pl.fun$pdf.version$heights)) * 2),
                         name = "pl.fun")

png("/mnt/Work/Oxford/BALI/Bali_Synth_Dbox/Analyses/Figures/SI/Level3_4.png",
    width = sum(as.numeric(gt3.4$widths)),
    height = sum(as.numeric(gt3.4$heights)),
    units = "cm", res = 600)
grid.newpage()
grid.draw(gt3.4)
dev.off()
