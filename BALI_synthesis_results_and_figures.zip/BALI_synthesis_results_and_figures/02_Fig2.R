####################################################################################################
### 02. Compact version of all effects sizes (Fig. 2)
###
### Plots all results in compact version - ie groups related datasets into one facet - for fig. 2 in
### the main text. Further neatening up of labels and panels is then carried out in inkscape
###
### Charlie Marsh
### charlie.marsh@mailbox.org; https://github.com/charliem2003
####################################################################################################

####################################################################################################
### Set-up

### load in libraries
library(gridExtra)
library(grid)
library(gtable)
library(ggplot2)

### Path to directory to which the project is placed - ***You need to change this***
baseDir <- "BALI_synthesis_results_and_figures"

### Get prepared data for plotting
source(file.path(baseDir, "01_Prepare_data.R"))

### Directory with individual spreadsheets with model results
resDir <- file.path(baseDir, "Results")

### Directory to save individual plot images too
figDir <- file.path(baseDir, "Figures", "Compact")

### Directory with plotting functions
funDir <- file.path(baseDir, "Functions")
source(file.path(funDir, "Plotting_functions.R"))

####################################################################################################
### Plot each level as separate plot and save (writes .pdf and .png versions)

### Level 1 - Structure & Environment
pl.str <- plot.cat(category = "Structure & Environment", subcategory = NULL, compact = TRUE,
                   label.category = TRUE, label.level = TRUE, label.cex = 7.3, label.x = TRUE, label.y = FALSE,
                   hline = FALSE, cat.colour = "white", facet.colour = "grey95",
                   save.image = TRUE, print = FALSE, return.plot = TRUE, path = figDir)
grid.newpage()
grid.draw(pl.str)

### Level 2 - Traits
pl.trpho <- plot.cat(category = "Photosynthesis traits", subcategory = NULL, compact = TRUE,
                     label.category = TRUE, label.level = TRUE, label.cex = 7.3, label.x = TRUE, label.y = FALSE,
                     hline = FALSE, cat.colour = "white", facet.colour = "grey95",
                     save.image = TRUE, print = FALSE, return.plot = TRUE, path = figDir)
grid.newpage()
grid.draw(pl.trpho)

pl.trnut <- plot.cat(category = "Nutrient traits", subcategory = NULL, compact = TRUE,
                     label.category = TRUE, label.level = TRUE, label.cex = 7.3, label.x = TRUE, label.y = FALSE,
                     hline = FALSE, cat.colour = "white", facet.colour = "grey95",
                     save.image = TRUE, print = FALSE, return.plot = TRUE, path = figDir)
grid.newpage()
grid.draw(pl.trnut)

pl.trstr <- plot.cat(category = "Structural traits", subcategory = NULL, compact = TRUE,
                     label.category = TRUE, label.level = TRUE, label.cex = 7.3, label.x = TRUE, label.y = FALSE,
                     hline = FALSE, cat.colour = "white", facet.colour = "grey95",
                     save.image = TRUE, print = FALSE, return.plot = TRUE, path = figDir)
grid.newpage()
grid.draw(pl.trstr)

### Level 3 - Biodiversity
pl.bio <- plot.cat(category = "Biodiversity", subcategory = NULL, compact = TRUE,
                   label.category = TRUE, label.level = TRUE, label.cex = 7.3, label.x = TRUE, label.y = FALSE,
                   hline = FALSE, cat.colour = "white", facet.colour = "grey95",
                   save.image = TRUE, print = FALSE, return.plot = TRUE, path = figDir)
grid.newpage()
grid.draw(pl.bio)

### Level 4 - Functioning
pl.fun <- plot.cat(category = "Functioning", subcategory = NULL, compact = TRUE,
                   label.category = TRUE, label.level = TRUE, label.cex = 7.3, label.x = TRUE, label.y = FALSE,
                   hline = FALSE, cat.colour = "white", facet.colour = "grey95",
                   save.image = TRUE, print = FALSE, return.plot = TRUE, path = figDir)
grid.newpage()
grid.draw(pl.fun)

####################################################################################################
### It is best to put the five plots together in an exernal editor, such as inkscape, but they can 
### be assembled using cowplot (warning, you will need a large plot window)

cowplot::plot_grid(pl.str,
                   grid.arrange(pl.trnut, pl.trstr, nrow = 2),
                   pl.trpho,
                   pl.bio,
                   pl.fun, ncol = 5, align = "h", axis = "t")
