############################################################################
### make_quadrats - function that assigns subplots to a new level - quadrats
### 20/04/2018
###
### args:
###   dd:  The Data frame of the input data with columns Plot and Subplot. 
###        Plot names must be one of the standard names categories.
###
### output:
###   Incporporates Quadrat and the unique identifier Quadrat.id into the 
###   original data frame.
###
###   Also outputs a plot with the quadrat assignments for each sampled Plot
###
############################################################################

make_quadrats <- function(dd) {
  require(ggplot2)
  
  ### list of sampled plots
  plot.list <- unique(dd$Plot)
  
  all_coords <- data.frame()
  for(plot in plot.list) {
    ### Standard plots
    if(plot %in% c("Belian", "BN", "BS", "DC1", "DC2", "LF",
                   "CarBel", "CarBN", "CarBS", "DCar1", "DCar2", "CarLF",
                   "MLA-01", "SAF-02", "SAF-01", "DAN-04", "DAN-05", "SAF-04", "SAF-03",
                   "BEL", "BNT", "BSO", "DAS1", "DAF2", "SLF", "ESA")) {
      coords <- data.frame(Plot = plot,
                           Subplot = c(1,   2,  3,  4,  5,
                                       10,  9,  8,  7,  6,
                                       11, 12, 13, 14, 15,
                                       20, 19, 18, 17, 16,
                                       21, 22, 23, 24, 25),
                           x = c(1, 2, 3, 4, 5,
                                 1, 2, 3, 4, 5,
                                 1, 2, 3, 4, 5,
                                 1, 2, 3, 4, 5,
                                 1, 2, 3, 4, 5),
                           y = c(1, 1, 1, 1, 1,
                                 2, 2, 2, 2, 2,
                                 3, 3, 3, 3, 3,
                                 4, 4, 4, 4, 4,
                                 5, 5, 5, 5, 5),
                           Quadrat = c("A", "B", "B", "B", "B",
                                       "A", "A", "B", "C", "C",
                                       "A", "A", "C", "C", "C",
                                       "D", "D", "E", "E", "E",
                                       "D", "D", "D", "E", "E"))
    }
    
    ### E Plot
    if(plot %in% c("E", "CarE", "SAF-03", "ESA")){
      coords <- data.frame(Plot = plot,
                           Subplot = c(1,   2,  3,  4,  5,  6,  7,
                                       14, 13, 12, 11, 10,  9,  8,
                                       15, 16, 17, 18, 19,
                                       22, 21, 20,
                                       23, 24, 25),
                           x = c(1, 2, 3, 4, 5, 6, 7,
                                 1, 2, 3, 4, 5, 6, 7,
                                 3, 4, 5, 6, 7,
                                 3, 4, 5,
                                 3, 4, 5),
                           y = c(1, 1, 1, 1, 1, 1, 1,
                                 2, 2, 2, 2, 2, 2, 2,
                                 3, 3, 3, 3, 3,
                                 4, 4, 4,
                                 5, 5, 5),
                           Quadrat = c("A", "A", "A", "B", "B", "C", "C",
                                       "A", "A", "B", "B", "B", "C", "C",
                                       "D", "D", "D", "D", "C",
                                       "E", "E", "D",
                                       "E", "E", "E"))
    }
    
    ### Oil Palm Plot
    if(plot == "OP"){
      coords <- data.frame(Plot = plot,
                           Subplot = c(1, 2, 3,
                                       6, 5, 4,
                                       7, 8, 9),
                           x = c(1, 2, 3,
                                 1, 2, 3,
                                 1, 2, 3),
                           y = c(1, 1, 1,
                                 2, 2, 2,
                                 3, 3, 3),
                           Quadrat = c("A", "A", "A",
                                       "B", "B", "A",
                                       "B", "B", "B"))
    }
    
    ### Seraya Plot
    if(plot %in% c("Seraya", "CarSer", "MLA-02", "SER")){
      coords <- data.frame(Plot = plot,
                           Subplot = c( 1,  2,  3,  4,  5,  6,
                                        11, 10,  9,  8,  7,
                                        12, 13, 14, 15, 16,
                                        21, 20, 19, 18, 17,
                                        22, 23, 24, 25),
                           x = c(1, 2, 3, 4, 5, 6,
                                 1, 2, 3, 4, 5,
                                 1, 2, 3, 4, 5,
                                 1, 2, 3, 4, 5,
                                 1, 2, 3, 4),
                           y = c(1, 1, 1, 1, 1, 1,
                                 2, 2, 2, 2, 2,
                                 3, 3, 3, 3, 3,
                                 4, 4, 4, 4, 4,
                                 5, 5, 5, 5),
                           Quadrat = c("A", "B", "B", "C", "C", "C",
                                       "A", "B", "B", "C", "C",
                                       "A", "A", "B", "D", "D",
                                       "A", "E", "E", "D", "D",
                                       "E", "E", "E", "D"))
    }
    
    ### Tower Plot
    if(plot %in% c("Tower", "CarTow", "SAF-05", "CON / GRD", "CON/GRD", "CON", "GRD")){
      coords <- data.frame(Plot = plot,
                           Subplot = c(     1,                14, 15,
                                            3,   2,            18, 17, 16,
                                            5,   4,    19, 20, 21, 22,
                                            7,   6,    25, 24, 23,
                                            9,   8,
                                            11, 10,
                                            13, 12),
                           x = c(   2,             7, 8,
                                    1, 2,          6, 7, 8,
                                    1, 2,    4, 5, 6, 7,
                                    1, 2,    4, 5, 6,
                                    1, 2,
                                    1, 2,
                                    1, 2),
                           y = c(   1,             1, 1,
                                    2, 2,          2, 2, 2,
                                    3, 3,    3, 3, 3, 3,
                                    4, 4,    4, 4, 4,
                                    5, 5,
                                    6, 6,
                                    7, 7),
                           Quadrat = c(     "A",                     "D", "D",
                                            "A", "A",                "D", "D", "D",
                                            "A", "A",      "E", "E", "E", "D",
                                            "B", "B",      "E", "E", "E",
                                            "B", "B",
                                            "C", "C",
                                            "C", "C"))
    }
    all_coords <- rbind(all_coords, coords)
  }

  #### plot quadrats
  p <- ggplot2::ggplot(all_coords, aes(x, y)) +
    facet_wrap(~Plot, scales = "free") +
    theme_void() +
    geom_tile(aes(fill = Quadrat), colour = "black") +
    geom_text(aes(label = Subplot))
  print(p)
  
  ###### Join with original data frame
  dd.temp <- dd[, 1:4]
  dd.temp$id <- paste(factor(with(dd.temp, paste(Plot, Subplot, sep = "."))))
  all_coords$id <- paste(factor(with(all_coords, paste(Plot, Subplot, sep = "."))))
  
  dd.temp <- dplyr::left_join(dd.temp, all_coords[, c("id", "Quadrat")], "id")
  dd$Quadrat <- dd.temp$Quadrat
  dd$Quadrat.id <- paste(factor(with(dd, paste(Plot, Quadrat, sep = "."))))
  return(dd)
}