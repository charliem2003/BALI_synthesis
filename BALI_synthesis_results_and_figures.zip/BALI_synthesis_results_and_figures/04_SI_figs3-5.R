####################################################################################################
### 04. Extended plots of all results for the Supplementary Material (figs S3-5)
###
### Each category is plotted in long version with full labelling for the SI - ie there is only one 
### dataset per facet (as opposed to the version in the main text that groups some related datasets
### into one facet
###
### Charlie Marsh
### charlie.marsh@mailbox.org; https://github.com/charliem2003
####################################################################################################

####################################################################################################
### Set-up

### load in libraries
library(gridExtra)
library(grid)
library(gtable)
library(ggplot2)

### Path to directory to which the project is placed - ***You need to change this***
baseDir <- "BALI_synthesis_results_and_figures"

### Get prepared data for plotting
source(file.path(baseDir, "01_Prepare_data.R"))

### Directory with individual spreadsheets with model results
resDir <- file.path(baseDir, "Results")

### Directory to save individual plot images too
figDir <- file.path(baseDir, "Figures", "SI")

### Directory with plotting functions
funDir <- file.path(baseDir, "Functions")
source(file.path(funDir, "Plotting_functions.R"))

####################################################################################################
#### Plot 1: Level 1 Structure, Microclimate, Soil properties
####################################################################################################

### Level 1 - Structure, microclimate and soil properties
pl.str <- plot.cat(subcategory = "Structure", label.category = TRUE, label.level = TRUE, label.x = TRUE, compact = FALSE,
                   label.cex = 7.3, cat.colour = "white", save.image = FALSE, print = FALSE, return.plot = TRUE)
pl.micro <- plot.cat(subcategory = "Microclimate", label.category = TRUE, label.level = TRUE, label.x = TRUE, compact = FALSE,
                     label.cex = 7.3, cat.colour = "white", save.image = FALSE, print = FALSE, return.plot = TRUE)
pl.soil <- plot.cat(subcategory = "Soil properties", label.category = TRUE, label.level = TRUE, label.x = TRUE, compact = FALSE,
                    label.cex = 7.3, cat.colour = "white", save.image = FALSE, print = FALSE, return.plot = TRUE)

gt1 <- gtable(widths = unit(c(sum(as.numeric(pl.str$widths)), 0.5,
                              sum(as.numeric(pl.micro$widths)), 0.5,
                              sum(as.numeric(pl.soil$widths))),
                            "cm"),
              heights = unit(c(0.75,
                               rep(c(1, 0.75),
                                   max(as.numeric(
                                     strtrim(pl.soil$layout$name[grep("[0-9]", strtrim(pl.soil$layout$name, 2))], 2)),
                                     na.rm = TRUE) + 1)),
                             "cm"))

### column 1 - Structure
gt1 <- gtable_add_grob(gt1, pl.str,
                       l = 1, r = 1, t = 1,
                       b = 3 + (length(grep("1.75", pl.str$heights)) * 2),
                       name = "pl.str")

### column 2 - Microclimate
gt1 <- gtable_add_grob(gt1, pl.micro,
                       l = 3, r = 3, t = 1,
                       b = 3 + (length(grep("1.75", pl.micro$heights)) * 2),
                       name = "pl.micro")

### column 3 - Soil properties
gt1 <- gtable_add_grob(gt1, pl.soil,
                       l = 5, r = 5, t = 1,
                       b = 3 + (length(grep("1.75", pl.soil$heights)) * 2),
                       name = "pl.soil")

png(file.path(figDir, "Level1.png"),
    width = sum(as.numeric(gt1$widths)),
    height = sum(as.numeric(gt1$heights)),
    units = "cm", res = 600)
grid.newpage()
grid.draw(gt1)
dev.off()

library(extrafont)
font_import()
loadfonts(device = "pdf")
cairo_pdf(file.path(figDir, "Level1.pdf"),
    width = sum(as.numeric(gt1$widths)) * 0.3937,
    height = sum(as.numeric(gt1$heights)) * 0.3937,
    family = "Helvetica")
grid.newpage()
grid.draw(gt1)
dev.off()

################################################################################
#### Plot 2: Level 2 - col1: Str traits, col2: Nutr traits, col3: Photo traits
################################################################################

### Level 2
pl.strait <- plot.cat(subcategory = "Structural traits", label.category = TRUE, label.level = TRUE, label.x = TRUE, compact = FALSE, 
                      label.cex = 7.3, cat.colour = "white", save.image = FALSE, print = FALSE, return.plot = TRUE)
pl.ptrait <- plot.cat(subcategory = "Photosynthesis traits", label.category = TRUE, label.level = TRUE, label.x = TRUE, compact = FALSE,
                      label.cex = 7.3, cat.colour = "white", save.image = FALSE, print = FALSE, return.plot = TRUE)
pl.ntrait <- plot.cat(subcategory = "Nutrient traits", label.category = TRUE, label.level = TRUE, label.x = TRUE, compact = FALSE,
                      label.cex = 7.3, cat.colour = "white", save.image = FALSE, print = FALSE, return.plot = TRUE)

gt2 <- gtable(widths = unit(c(sum(as.numeric(pl.strait$widths)), 0.5,
                              sum(as.numeric(pl.ntrait$widths)), 0.5,
                              sum(as.numeric(pl.ptrait$widths))),
                            "cm"),
              heights = unit(c(0.75,
                               rep(c(1, 0.75),
                                   max(as.numeric(
                                     strtrim(pl.ptrait$layout$name[grep("[0-9]", strtrim(pl.ptrait$layout$name, 2))], 2)),
                                     na.rm = TRUE) + 1)),
                             "cm"))

### column 1 - Photosynthesis traits
gt2 <- gtable_add_grob(gt2, pl.ptrait,
                       l = 1, r = 1,
                       t = 1,
                       b = 3 + (length(grep("1.75", pl.ptrait$heights)) * 2),
                       name = "pl.ptraits")

### column 2 - Nutrient traits
gt2 <- gtable_add_grob(gt2, pl.ntrait,
                       l = 3, r = 3,
                       t = 1,
                       b = 3 + (length(grep("1.75", pl.ntrait$heights)) * 2),
                       name = "pl.ntraits")

### column 3 - Structural traits
gt2 <- gtable_add_grob(gt2, pl.strait,
                       l = 5, r = 5,
                       t = 1,
                       b = 3 + (length(grep("1.75", pl.strait$heights)) * 2),
                       name = "pl.straits")

png(file.path(figDir, "Level2.png"),
    width = sum(as.numeric(gt2$widths)),
    height = sum(as.numeric(gt2$heights)),
    units = "cm", res = 600)
grid.newpage()
grid.draw(gt2)
dev.off()

cairo_pdf(file.path(figDir, "Level2.pdf"),
    width = sum(as.numeric(gt2$widths)) * 0.3937,
    height = sum(as.numeric(gt2$heights)) * 0.3937,
    family = "Helvetica")
grid.newpage()
grid.draw(gt2)
dev.off()

################################################################################
#### Plot 3: Level 3+4 - col1: Diversity 1-10, col2: Diversity 11:22, col3: Functions
################################################################################

pl.div1 <- plot.cat(subcategory = "Biodiversity (1)", label.category = TRUE, label.level = TRUE, label.x = TRUE, compact = FALSE,
                    label.cex = 7.3, cat.colour = "white", save.image = FALSE, print = FALSE, return.plot = TRUE)
pl.div2 <- plot.cat(subcategory = "Biodiversity (2)", label.category = TRUE, label.level = TRUE, label.x = TRUE, compact = FALSE,
                    label.cex = 7.3, cat.colour = "white", save.image = FALSE, print = FALSE, return.plot = TRUE)
pl.fun <- plot.cat(subcategory = "Functioning", label.category = TRUE, label.level = TRUE, label.x = TRUE, compact = FALSE,
                   label.cex = 7.3, cat.colour = "white", save.image = FALSE, print = FALSE, return.plot = TRUE)

gt3.4 <- gtable(widths = unit(c(sum(as.numeric(pl.div1$widths)), 0.5,
                                sum(as.numeric(pl.div1$widths)), 0.5,
                                sum(as.numeric(pl.div1$widths))),
                              "cm"),
                heights = unit(c(0.75,
                                 rep(c(0.75, 1),
                                     max(as.numeric(
                                       strtrim(pl.div1$layout$name[grep("[0-9]", strtrim(pl.div1$layout$name, 2))], 2)),
                                       na.rm = TRUE) + 1)),
                               "cm"))

### column 1 - First half of biodiversity 
gt3.4 <- gtable_add_grob(gt3.4, pl.div1,
                         l = 1, r = 1, t = 1,
                         b = 3 + (length(grep("1.75", pl.div1$heights)) * 2),
                         name = "pl.div1")

### column 2 - Second half of biodiversity 
gt3.4 <- gtable_add_grob(gt3.4, pl.div2,
                         l = 3, r = 3, t = 1,
                         b = 3 + (length(grep("1.75", pl.div2$heights)) * 2),
                         name = "pl.div2")

### column 3 - Functioning 
gt3.4 <- gtable_add_grob(gt3.4, pl.fun,
                         l = 5, r = 5, t = 1,
                         b = 3 + (length(grep("1.75", pl.fun$heights)) * 2),
                         name = "pl.fun")

png(file.path(figDir, "Level3_4.png"),
    width = sum(as.numeric(gt3.4$widths)),
    height = sum(as.numeric(gt3.4$heights)),
    units = "cm", res = 600)
grid.newpage()
grid.draw(gt3.4)
dev.off()

cairo_pdf(file.path(figDir, "Level3_4.pdf"),
    width = sum(as.numeric(gt3.4$widths)) * 0.3937,
    height = sum(as.numeric(gt3.4$heights)) * 0.3937,
    family = "Helvetica")
grid.newpage()
grid.draw(gt3.4)
dev.off()
