################################################################################
### Plots all results in compact version - ie groups related datasets into one facet - for fig. 2 in
### the main text. Generates separate plots that are then processed and joined in inkscape
### Charlie Marsh
### charlie.marsh@mailbox.org; https://github.com/charliem2003
################################################################################

library(gridExtra)
library(grid)
library(gtable)
library(ggplot2)
setwd("/mnt/Work/Oxford/BALI/Bali_Synth_Dbox/Analyses")

####################################################################################################
### Read in data

source("All_results/01_Prepare_data.R")
source("All_results/Plotting_functions.R")

####################################################################################################
### Plot each level as separate plot and save

### Level 1 - Structure & Environment
pl.str <- plot.cat(category = "Structure & Environment", subcategory = NULL, compact = TRUE,
                   label.category = TRUE, label.level = TRUE, label.cex = 7.3, label.x = TRUE, label.y = FALSE,
                   hline = FALSE, cat.colour = "white", facet.colour = "grey90",
                   save.image = TRUE, print = FALSE, return.plot = TRUE,
                   path = "/mnt/Work/Oxford/BALI/Bali_Synth_Dbox/Analyses/Figures/Raw")
grid.newpage()
grid.draw(pl.str$png.version)

### Level 2 - Traits
pl.trpho <- plot.cat(category = "Photosynthesis traits", subcategory = NULL, compact = TRUE,
                     label.category = TRUE, label.level = TRUE, label.cex = 7.3, label.x = TRUE, label.y = FALSE,
                     hline = FALSE, cat.colour = "white", facet.colour = "grey90",
                     save.image = TRUE, print = FALSE, return.plot = TRUE,
                     path = "/mnt/Work/Oxford/BALI/Bali_Synth_Dbox/Analyses/Figures/Raw")
grid.newpage()
grid.draw(pl.trpho$png.version)

pl.trnut <- plot.cat(category = "Nutrient traits", subcategory = NULL, compact = TRUE,
                     label.category = TRUE, label.level = TRUE, label.cex = 7.3, label.x = TRUE, label.y = FALSE,
                     hline = FALSE, cat.colour = "white", facet.colour = "grey90",
                     save.image = TRUE, print = FALSE, return.plot = TRUE,
                     path = "/mnt/Work/Oxford/BALI/Bali_Synth_Dbox/Analyses/Figures/Raw")
grid.newpage()
grid.draw(pl.trnut$png.version)

pl.trstr <- plot.cat(category = "Structural traits", subcategory = NULL, compact = TRUE,
                     label.category = TRUE, label.level = TRUE, label.cex = 7.3, label.x = TRUE, label.y = FALSE,
                     hline = FALSE, cat.colour = "white", facet.colour = "grey90",
                     save.image = TRUE, print = FALSE, return.plot = TRUE,
                     path = "/mnt/Work/Oxford/BALI/Bali_Synth_Dbox/Analyses/Figures/Raw")
grid.newpage()
grid.draw(pl.trstr$png.version)

### Level 3 - Biodiversity
pl.bio <- plot.cat(category = "Biodiversity", subcategory = NULL, compact = TRUE,
                   label.category = TRUE, label.level = TRUE, label.cex = 7.3, label.x = TRUE, label.y = FALSE,
                   hline = FALSE, cat.colour = "white", facet.colour = "grey90",
                   save.image = TRUE, print = FALSE, return.plot = TRUE,
                   path = "/mnt/Work/Oxford/BALI/Bali_Synth_Dbox/Analyses/Figures/Raw")
grid.newpage()
grid.draw(pl.bio$png.version)

### Level 4 - Functioning
pl.fun <- plot.cat(category = "Functioning", subcategory = NULL, compact = TRUE,
                   label.category = TRUE, label.level = TRUE, label.cex = 7.3, label.x = TRUE, label.y = FALSE,
                   hline = FALSE, cat.colour = "white", facet.colour = "grey90",
                   save.image = TRUE, print = FALSE, return.plot = TRUE,
                   path = "/mnt/Work/Oxford/BALI/Bali_Synth_Dbox/Analyses/Figures/Raw")
grid.newpage()
grid.draw(pl.fun$png.version)
